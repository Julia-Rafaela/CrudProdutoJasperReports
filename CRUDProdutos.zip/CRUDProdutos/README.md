# Exercício:
Considerando a database abaixo, criar um novo projeto Spring Boot Maven com dependências de Servlet, JSP, JSTL, JTDS, com uma tela que permita consultar as duas UDFs propostas. Classe de controle deve ter implantação de chamada GET e POST (tela com os atributos)
Fazer o CRUD da tabela Produto (codigo, nome, valor unitário e qtd estoque)
Na tela de produto, além dos botões para chamada do CRUD, fazer botões para as UDFs:

## a) 
A partir da tabela Produtos (codigo, nome, valor unitário e qtd estoque), quantos produtos estão com estoque abaixo de um valor de entrada
## b) 
Uma tabela com o código, o nome e a quantidade dos produtos que estão com o estoque abaixo de um valor de entrada
