package br.edu.fateczl.CRUDProdutos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudProdutosApplicationTests {

	@Test
	void contextLoads() {
	}

}
